<?php
include_once("inc/head.php");
include_once("inc/top.php");
include_once("inc/slide.php");
?>
<?php
include_once("inc/promo.php");
?>

<!-- End promo area -->
<?php
include_once("inc/mainContent.php");
?>
<!-- End main content area -->
<?php
include_once("inc/brand.php");
?>
<!-- End brands area -->

<?php
include_once("inc/widget.php");
?>

<!-- End product widget area -->
<?php
include_once("inc/footer.php");
?>