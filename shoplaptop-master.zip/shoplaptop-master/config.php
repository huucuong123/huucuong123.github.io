<?php 
  define('BASE_URL','http://localhost/laptopcu/');